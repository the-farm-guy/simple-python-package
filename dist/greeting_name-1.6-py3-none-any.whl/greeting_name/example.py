def hello():
    print('hello world')

def hello(name) :
    print(f'hello {name}')

def add(val1, val2):
    return val1 + val2
